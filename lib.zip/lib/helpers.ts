import type { Incident, RiskZone, SeverityLevel } from "@/lib/types"

// Time formatting for response timer
export function formatTimeAgo(timestamp: number): string {
  const seconds = Math.floor((Date.now() - timestamp) / 1000)
  if (seconds < 60) return `${seconds}s ago`
  const minutes = Math.floor(seconds / 60)
  if (minutes < 60) return `${minutes}m ago`
  const hours = Math.floor(minutes / 60)
  if (hours < 24) return `${hours}h ago`
  const days = Math.floor(hours / 24)
  return `${days}d ago`
}

// Severity weight for risk calculations
export function severityWeight(severity: SeverityLevel): number {
  switch (severity) {
    case "Critical":
      return 3
    case "High":
      return 2
    case "Medium":
      return 1
  }
}

// Haversine distance in km
function haversine(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371
  const dLat = ((lat2 - lat1) * Math.PI) / 180
  const dLon = ((lon2 - lon1) * Math.PI) / 180
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2)
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
}

// Calculate risk zones from incident data
export function calculateRiskZones(incidents: Incident[]): RiskZone[] {
  const RADIUS_KM = 0.5
  const activeIncidents = incidents.filter((i) => i.status === "Active")
  if (activeIncidents.length === 0) return []

  // Cluster incidents by proximity
  const clusters: { lat: number; lng: number; incidents: Incident[] }[] = []

  for (const incident of activeIncidents) {
    let foundCluster = false
    for (const cluster of clusters) {
      if (haversine(cluster.lat, cluster.lng, incident.latitude, incident.longitude) < RADIUS_KM) {
        cluster.incidents.push(incident)
        cluster.lat = (cluster.lat + incident.latitude) / 2
        cluster.lng = (cluster.lng + incident.longitude) / 2
        foundCluster = true
        break
      }
    }
    if (!foundCluster) {
      clusters.push({ lat: incident.latitude, lng: incident.longitude, incidents: [incident] })
    }
  }

  return clusters.map((cluster, i) => {
    const totalWeight = cluster.incidents.reduce(
      (sum, inc) => sum + severityWeight(inc.severity),
      0
    )
    let level: RiskZone["level"] = "green"
    if (totalWeight >= 6) level = "red"
    else if (totalWeight >= 3) level = "yellow"

    return {
      id: `zone-${i}`,
      latitude: cluster.lat,
      longitude: cluster.lng,
      level,
      incidentCount: cluster.incidents.length,
      label:
        level === "red"
          ? "High Risk Area"
          : level === "yellow"
            ? "Moderate Risk"
            : "Low Risk",
    }
  })
}

// Check if user is in a risk zone
export function isInRiskZone(
  userLat: number,
  userLng: number,
  zones: RiskZone[]
): RiskZone | null {
  for (const zone of zones) {
    if (zone.level === "red" && haversine(userLat, userLng, zone.latitude, zone.longitude) < 0.5) {
      return zone
    }
  }
  return null
}

// Dummy SMS simulation
export function simulateSMSAlert(phoneNumber: string, message: string) {
  console.log(`[SMS SIMULATION] To: ${phoneNumber} | Message: ${message}`)
}

// Generate sample incidents for demo
export function generateSampleIncidents(): Omit<Incident, "id">[] {
  const now = Date.now()
  return [
    {
      userId: "demo-user-1",
      email: "tourist1@example.com",
      latitude: 40.7128,
      longitude: -74.006,
      timestamp: now - 1800000,
      severity: "Critical",
      status: "Active",
      type: "SOS",
      description: "Emergency SOS triggered near Times Square",
      emergencyNumber: "+1-555-0101",
    },
    {
      userId: "demo-user-2",
      email: "tourist2@example.com",
      latitude: 40.7589,
      longitude: -73.9851,
      timestamp: now - 3600000,
      severity: "High",
      status: "Active",
      type: "Theft",
      description: "Bag snatching reported near Central Park",
      emergencyNumber: "+1-555-0102",
    },
    {
      userId: "demo-user-3",
      email: "tourist3@example.com",
      latitude: 40.7484,
      longitude: -73.9857,
      timestamp: now - 7200000,
      severity: "Medium",
      status: "Active",
      type: "Harassment",
      description: "Verbal harassment near Empire State Building",
      emergencyNumber: "+1-555-0103",
    },
    {
      userId: "demo-user-4",
      email: "tourist4@example.com",
      latitude: 40.6892,
      longitude: -74.0445,
      timestamp: now - 900000,
      severity: "Critical",
      status: "Active",
      type: "SOS",
      description: "Medical emergency near Statue of Liberty ferry",
      emergencyNumber: "+1-555-0104",
    },
    {
      userId: "demo-user-5",
      email: "tourist5@example.com",
      latitude: 40.7308,
      longitude: -73.9973,
      timestamp: now - 14400000,
      severity: "Medium",
      status: "Resolved",
      type: "Unsafe Area",
      description: "Poorly lit area reported in Greenwich Village",
      emergencyNumber: "+1-555-0105",
    },
    {
      userId: "demo-user-6",
      email: "tourist6@example.com",
      latitude: 40.7061,
      longitude: -74.0087,
      timestamp: now - 5400000,
      severity: "High",
      status: "Active",
      type: "Theft",
      description: "Pickpocketing incident near Wall Street",
      emergencyNumber: "+1-555-0106",
    },
  ]
}
