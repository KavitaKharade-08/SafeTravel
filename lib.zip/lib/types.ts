export interface Incident {
  id: string
  userId: string
  email: string
  latitude: number
  longitude: number
  timestamp: number
  severity: "Critical" | "High" | "Medium"
  status: "Active" | "Resolved"
  type: "SOS" | "Harassment" | "Theft" | "Unsafe Area" | "Other"
  description?: string
  emergencyNumber?: string
}

export interface UserProfile {
  uid: string
  email: string
  emergencyNumber: string
  createdAt: number
  lastLatitude?: number
  lastLongitude?: number
  lastLocationUpdate?: number
}

export interface RiskZone {
  id: string
  latitude: number
  longitude: number
  level: "green" | "yellow" | "red"
  incidentCount: number
  label: string
}

export type SeverityLevel = "Critical" | "High" | "Medium"
export type IncidentStatus = "Active" | "Resolved"
export type IncidentType = "SOS" | "Harassment" | "Theft" | "Unsafe Area" | "Other"
