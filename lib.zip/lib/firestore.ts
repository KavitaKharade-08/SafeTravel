"use client"

import {
  collection,
  addDoc,
  updateDoc,
  doc,
  onSnapshot,
  query,
  orderBy,
  setDoc,
  getDoc,
  getDocs,
  where,
  type Unsubscribe,
} from "firebase/firestore"
import { getFirebaseDb } from "@/lib/firebase"
import type { Incident, UserProfile } from "@/lib/types"

// ---- INCIDENTS ----

export async function createIncident(data: Omit<Incident, "id">): Promise<string> {
  const docRef = await addDoc(collection(getFirebaseDb(), "incidents"), data)
  return docRef.id
}

export async function resolveIncident(incidentId: string): Promise<void> {
  await updateDoc(doc(getFirebaseDb(), "incidents", incidentId), {
    status: "Resolved",
  })
}

export function subscribeToIncidents(
  callback: (incidents: Incident[]) => void
): Unsubscribe {
  const q = query(collection(getFirebaseDb(), "incidents"), orderBy("timestamp", "desc"))
  return onSnapshot(q, (snapshot) => {
    const incidents: Incident[] = snapshot.docs.map((d) => ({
      id: d.id,
      ...d.data(),
    })) as Incident[]
    callback(incidents)
  })
}

export function subscribeToActiveIncidents(
  callback: (incidents: Incident[]) => void
): Unsubscribe {
  const q = query(
    collection(getFirebaseDb(), "incidents"),
    where("status", "==", "Active"),
    orderBy("timestamp", "desc")
  )
  return onSnapshot(q, (snapshot) => {
    const incidents: Incident[] = snapshot.docs.map((d) => ({
      id: d.id,
      ...d.data(),
    })) as Incident[]
    callback(incidents)
  })
}

// ---- USER PROFILES ----

export async function saveUserProfile(profile: UserProfile): Promise<void> {
  await setDoc(doc(getFirebaseDb(), "users", profile.uid), profile)
}

export async function getUserProfile(uid: string): Promise<UserProfile | null> {
  const snap = await getDoc(doc(getFirebaseDb(), "users", uid))
  return snap.exists() ? (snap.data() as UserProfile) : null
}

export async function updateUserLocation(
  uid: string,
  lat: number,
  lng: number
): Promise<void> {
  await updateDoc(doc(getFirebaseDb(), "users", uid), {
    lastLatitude: lat,
    lastLongitude: lng,
    lastLocationUpdate: Date.now(),
  })
}

export function subscribeToUsers(
  callback: (users: UserProfile[]) => void
): Unsubscribe {
  return onSnapshot(collection(getFirebaseDb(), "users"), (snapshot) => {
    const users: UserProfile[] = snapshot.docs.map((d) => d.data()) as UserProfile[]
    callback(users)
  })
}

export async function getAllUsers(): Promise<UserProfile[]> {
  const snapshot = await getDocs(collection(getFirebaseDb(), "users"))
  return snapshot.docs.map((d) => d.data()) as UserProfile[]
}
