"use client"

import {
  createContext,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from "react"
import {
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  type User,
} from "firebase/auth"
import { getFirebaseAuth } from "@/lib/firebase"
import { saveUserProfile, getUserProfile } from "@/lib/firestore"
import type { UserProfile } from "@/lib/types"

interface AuthContextType {
  user: User | null
  profile: UserProfile | null
  loading: boolean
  login: (email: string, password: string) => Promise<void>
  register: (email: string, password: string, emergencyNumber: string) => Promise<void>
  logout: () => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [profile, setProfile] = useState<UserProfile | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(getFirebaseAuth(), async (firebaseUser) => {
      setUser(firebaseUser)
      if (firebaseUser) {
        const p = await getUserProfile(firebaseUser.uid)
        setProfile(p)
      } else {
        setProfile(null)
      }
      setLoading(false)
    })
    return unsubscribe
  }, [])

  async function login(email: string, password: string) {
    const cred = await signInWithEmailAndPassword(getFirebaseAuth(), email, password)
    const p = await getUserProfile(cred.user.uid)
    setProfile(p)
  }

  async function register(email: string, password: string, emergencyNumber: string) {
    const cred = await createUserWithEmailAndPassword(getFirebaseAuth(), email, password)
    const newProfile: UserProfile = {
      uid: cred.user.uid,
      email,
      emergencyNumber,
      createdAt: Date.now(),
    }
    await saveUserProfile(newProfile)
    setProfile(newProfile)
  }

  async function logout() {
    await signOut(getFirebaseAuth())
    setProfile(null)
  }

  return (
    <AuthContext.Provider value={{ user, profile, loading, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
