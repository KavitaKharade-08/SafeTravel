"use client"

import { IncidentReportForm } from "@/components/incident-report-form"

export default function ReportPage() {
  return (
    <main className="mx-auto max-w-lg px-4 py-6">
      <IncidentReportForm />
    </main>
  )
}
