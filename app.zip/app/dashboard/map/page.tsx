"use client"

import { SafetyMap } from "@/components/safety-map"
import { SafeRoutePlanner } from "@/components/safe-route-planner"

export default function MapPage() {
  return (
    <main className="mx-auto max-w-3xl px-4 py-6">
      <div className="space-y-6">
        <SafetyMap />
        <SafeRoutePlanner />
      </div>
    </main>
  )
}
