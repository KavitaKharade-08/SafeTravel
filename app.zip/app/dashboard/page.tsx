"use client"

import { useState } from "react"
import { useAuth } from "@/lib/auth-context"
import { SOSButton } from "@/components/sos-button"
import { LocationDisplay } from "@/components/location-display"
import { IncidentReportForm } from "@/components/incident-report-form"
import { SafetyMap } from "@/components/safety-map"
import { SafeRoutePlanner } from "@/components/safe-route-planner"
import { Button } from "@/components/ui/button"
import {
  ShieldCheck,
  FileWarning,
  Map,
  Navigation,
} from "lucide-react"

export default function DashboardPage() {
  const { user } = useAuth()
  const [showReport, setShowReport] = useState(false)
  const [activeSection, setActiveSection] = useState<
    "home" | "heatmap" | "route"
  >("home")

  if (!user) return null

  return (
    <main className="mx-auto max-w-5xl px-4 py-6">
      <div className="mb-6">
        <div className="flex items-center gap-3">
          <ShieldCheck className="h-7 w-7 text-primary" />
          <div>
            <h1 className="text-2xl font-bold text-foreground text-balance">
              Safety Dashboard
            </h1>
            <p className="text-sm text-muted-foreground">
              Welcome, {user.email}
            </p>
          </div>
        </div>
      </div>

      {/* Quick actions bar - desktop visible */}
      <div className="mb-6 hidden gap-2 lg:flex">
        <Button
          variant={activeSection === "home" ? "default" : "outline"}
          size="sm"
          onClick={() => setActiveSection("home")}
        >
          <ShieldCheck className="mr-1.5 h-4 w-4" />
          Home
        </Button>
        <Button
          variant={activeSection === "heatmap" ? "default" : "outline"}
          size="sm"
          onClick={() => setActiveSection("heatmap")}
        >
          <Map className="mr-1.5 h-4 w-4" />
          Safety Heatmap
        </Button>
        <Button
          variant={activeSection === "route" ? "default" : "outline"}
          size="sm"
          onClick={() => setActiveSection("route")}
        >
          <Navigation className="mr-1.5 h-4 w-4" />
          Safe Route
        </Button>
      </div>

      {activeSection === "home" && (
        <div className="grid gap-6 lg:grid-cols-[1fr_360px]">
          <div className="flex flex-col gap-6">
            {/* SOS Section */}
            <section className="flex flex-col items-center gap-6 rounded-2xl border border-border bg-card p-8 shadow-sm">
              <div className="text-center">
                <h2 className="text-lg font-semibold text-foreground">
                  Emergency SOS
                </h2>
                <p className="mt-1 text-sm text-muted-foreground">
                  Tap the button to send your location to emergency services
                </p>
              </div>
              <SOSButton />
              <p className="text-xs text-muted-foreground">
                Your GPS coordinates will be recorded and emergency contact
                notified
              </p>
            </section>

            {/* Report Incident */}
            {showReport ? (
              <IncidentReportForm onClose={() => setShowReport(false)} />
            ) : (
              <Button
                variant="outline"
                className="h-14 w-full text-base"
                onClick={() => setShowReport(true)}
              >
                <FileWarning className="mr-2 h-5 w-5 text-primary" />
                Report an Incident
              </Button>
            )}

            {/* Location */}
            <LocationDisplay />
          </div>

          {/* Sidebar */}
          <div className="flex flex-col gap-6">
            <div className="rounded-xl border border-border bg-card p-5 shadow-sm">
              <h3 className="mb-3 text-sm font-semibold text-foreground">
                Safety Tips
              </h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-start gap-2">
                  <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                  Keep your phone charged and location services enabled
                </li>
                <li className="flex items-start gap-2">
                  <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                  Share your travel itinerary with trusted contacts
                </li>
                <li className="flex items-start gap-2">
                  <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                  Store emergency contacts and embassy numbers offline
                </li>
                <li className="flex items-start gap-2">
                  <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                  Keep digital copies of important documents secured
                </li>
                <li className="flex items-start gap-2">
                  <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                  Check safety heatmap before visiting new areas
                </li>
              </ul>
            </div>

            {/* Quick heatmap preview */}
            <div className="rounded-xl border border-border bg-card p-5 shadow-sm">
              <h3 className="mb-3 text-sm font-semibold text-foreground">
                Quick Map
              </h3>
              <div className="overflow-hidden rounded-lg border border-border">
                <iframe
                  title="Quick location map"
                  width="100%"
                  height="180"
                  style={{ border: 0 }}
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  src="https://maps.google.com/maps?q=40.7128,-74.006&z=13&output=embed"
                />
              </div>
              <Button
                variant="link"
                size="sm"
                className="mt-2 h-auto p-0 text-xs"
                onClick={() => setActiveSection("heatmap")}
              >
                View full safety heatmap
              </Button>
            </div>
          </div>
        </div>
      )}

      {activeSection === "heatmap" && <SafetyMap />}
      {activeSection === "route" && <SafeRoutePlanner />}
    </main>
  )
}
