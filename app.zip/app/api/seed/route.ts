import { NextResponse } from "next/server"

export async function GET() {
  // This endpoint returns the sample data structure for reference.
  // Actual seeding happens client-side via the admin dashboard since
  // Firebase client SDK is used throughout.
  return NextResponse.json({
    message: "Use the admin dashboard to seed sample data.",
    schema: {
      incidents: {
        userId: "string",
        email: "string",
        latitude: "number",
        longitude: "number",
        timestamp: "number (epoch ms)",
        severity: "Critical | High | Medium",
        status: "Active | Resolved",
        type: "SOS | Harassment | Theft | Unsafe Area | Other",
        description: "string (optional)",
        emergencyNumber: "string (optional)",
      },
      users: {
        uid: "string",
        email: "string",
        emergencyNumber: "string",
        createdAt: "number (epoch ms)",
        lastLatitude: "number (optional)",
        lastLongitude: "number (optional)",
        lastLocationUpdate: "number (optional)",
      },
    },
  })
}
