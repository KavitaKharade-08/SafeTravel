"use client"

import { useAuth } from "@/lib/auth-context"
import { useRouter } from "next/navigation"
import { useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Shield, MapPin, Bell, Loader2 } from "lucide-react"

export default function HomePage() {
  const { user, loading } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!loading && user) {
      router.push("/dashboard")
    }
  }, [user, loading, router])

  if (loading) {
    return (
      <div className="flex min-h-[calc(100vh-4rem)] items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  if (user) return null

  return (
    <main className="flex min-h-[calc(100vh-4rem)] flex-col items-center justify-center px-4 py-16">
      <div className="mx-auto max-w-2xl text-center">
        <div className="mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-2xl bg-primary shadow-lg">
          <Shield className="h-8 w-8 text-primary-foreground" />
        </div>

        <h1 className="mb-4 text-4xl font-extrabold tracking-tight text-foreground text-balance sm:text-5xl">
          Travel Safely, Anywhere
        </h1>
        <p className="mb-8 text-lg text-muted-foreground text-pretty">
          SafeTravel gives you instant access to emergency SOS alerts with live
          GPS tracking. Stay protected wherever your adventures take you.
        </p>

        <div className="flex flex-col items-center gap-3 sm:flex-row sm:justify-center">
          <Button size="lg" asChild>
            <Link href="/register">Get Started</Link>
          </Button>
          <Button variant="outline" size="lg" asChild>
            <Link href="/login">Sign In</Link>
          </Button>
        </div>

        <div className="mt-16 grid gap-6 sm:grid-cols-3">
          <div className="rounded-xl border border-border bg-card p-6 shadow-sm">
            <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
              <Bell className="h-5 w-5 text-primary" />
            </div>
            <h3 className="mb-1 font-semibold text-foreground">SOS Alerts</h3>
            <p className="text-sm text-muted-foreground">
              One-tap emergency button that sends your exact location instantly
            </p>
          </div>
          <div className="rounded-xl border border-border bg-card p-6 shadow-sm">
            <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
              <MapPin className="h-5 w-5 text-primary" />
            </div>
            <h3 className="mb-1 font-semibold text-foreground">
              Live Tracking
            </h3>
            <p className="text-sm text-muted-foreground">
              Real-time GPS coordinates displayed with embedded map view
            </p>
          </div>
          <div className="rounded-xl border border-border bg-card p-6 shadow-sm">
            <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
              <Shield className="h-5 w-5 text-primary" />
            </div>
            <h3 className="mb-1 font-semibold text-foreground">
              Secure & Private
            </h3>
            <p className="text-sm text-muted-foreground">
              Your data is encrypted and only shared during emergencies
            </p>
          </div>
        </div>
      </div>
    </main>
  )
}
