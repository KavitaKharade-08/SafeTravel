"use client"

import { useEffect, useState } from "react"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { subscribeToUsers, subscribeToIncidents } from "@/lib/firestore"
import { calculateRiskZones, isInRiskZone } from "@/lib/helpers"
import { Users, Mail, Phone, MapPin, Shield, AlertTriangle } from "lucide-react"
import type { UserProfile, Incident, RiskZone } from "@/lib/types"

export default function AdminTouristsPage() {
  const [users, setUsers] = useState<UserProfile[]>([])
  const [zones, setZones] = useState<RiskZone[]>([])

  useEffect(() => {
    const unsub1 = subscribeToUsers(setUsers)
    const unsub2 = subscribeToIncidents((incidents: Incident[]) => {
      setZones(calculateRiskZones(incidents))
    })
    return () => {
      unsub1()
      unsub2()
    }
  }, [])

  function getUserStatus(user: UserProfile) {
    if (user.lastLatitude && user.lastLongitude) {
      const risk = isInRiskZone(user.lastLatitude, user.lastLongitude, zones)
      if (risk) return "In Risk Zone"
    }
    return "Safe"
  }

  return (
    <div className="p-4 lg:p-6">
      <div className="mb-6">
        <h1 className="text-xl font-bold text-foreground">Registered Tourists</h1>
        <p className="text-sm text-muted-foreground">
          {users.length} tourist{users.length !== 1 ? "s" : ""} registered
        </p>
      </div>

      {/* Desktop table */}
      <div className="hidden overflow-x-auto rounded-xl border border-border lg:block">
        <table className="w-full">
          <thead>
            <tr className="border-b border-border bg-secondary/50">
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Tourist
              </th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Emergency Number
              </th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Last Known Location
              </th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Status
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {users.map((u) => {
              const status = getUserStatus(u)
              return (
                <tr
                  key={u.uid}
                  className="transition-colors hover:bg-secondary/30"
                >
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10 text-xs font-bold text-primary">
                        {u.email.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <p className="text-sm font-medium text-foreground">
                          {u.email}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          ID: {u.uid.slice(0, 8)}...
                        </p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1.5 text-sm text-foreground">
                      <Phone className="h-3.5 w-3.5 text-muted-foreground" />
                      {u.emergencyNumber || "Not set"}
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    {u.lastLatitude && u.lastLongitude ? (
                      <div className="flex items-center gap-1.5 text-sm text-foreground">
                        <MapPin className="h-3.5 w-3.5 text-muted-foreground" />
                        {u.lastLatitude.toFixed(4)}, {u.lastLongitude.toFixed(4)}
                      </div>
                    ) : (
                      <span className="text-sm text-muted-foreground">
                        Unknown
                      </span>
                    )}
                  </td>
                  <td className="px-4 py-3">
                    <span
                      className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-semibold ${
                        status === "Safe"
                          ? "bg-green-500/15 text-green-500"
                          : "bg-red-500/15 text-red-500"
                      }`}
                    >
                      {status === "Safe" ? (
                        <Shield className="h-3 w-3" />
                      ) : (
                        <AlertTriangle className="h-3 w-3" />
                      )}
                      {status}
                    </span>
                  </td>
                </tr>
              )
            })}
            {users.length === 0 && (
              <tr>
                <td
                  colSpan={4}
                  className="px-4 py-12 text-center text-sm text-muted-foreground"
                >
                  No registered tourists yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Mobile cards */}
      <div className="space-y-3 lg:hidden">
        {users.map((u) => {
          const status = getUserStatus(u)
          return (
            <Card key={u.uid}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10 text-xs font-bold text-primary">
                      {u.email.charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <p className="text-sm font-medium text-foreground">
                        {u.email}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {u.uid.slice(0, 8)}...
                      </p>
                    </div>
                  </div>
                  <span
                    className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-semibold ${
                      status === "Safe"
                        ? "bg-green-500/15 text-green-500"
                        : "bg-red-500/15 text-red-500"
                    }`}
                  >
                    {status}
                  </span>
                </div>
                <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
                  <div className="flex items-center gap-1.5 text-muted-foreground">
                    <Phone className="h-3 w-3" />
                    {u.emergencyNumber || "Not set"}
                  </div>
                  <div className="flex items-center gap-1.5 text-muted-foreground">
                    <MapPin className="h-3 w-3" />
                    {u.lastLatitude
                      ? `${u.lastLatitude.toFixed(3)}, ${u.lastLongitude?.toFixed(3)}`
                      : "Unknown"}
                  </div>
                </div>
              </CardContent>
            </Card>
          )
        })}
        {users.length === 0 && (
          <div className="py-12 text-center text-sm text-muted-foreground">
            No registered tourists yet.
          </div>
        )}
      </div>
    </div>
  )
}
