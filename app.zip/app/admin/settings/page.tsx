"use client"

import { useState } from "react"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Settings, Brain, Gauge, Weight } from "lucide-react"
import { toast } from "sonner"

export default function AdminSettingsPage() {
  const [aiEnabled, setAiEnabled] = useState(true)
  const [sensitivity, setSensitivity] = useState<"low" | "medium" | "high">("medium")
  const [criticalWeight, setCriticalWeight] = useState(3)
  const [highWeight, setHighWeight] = useState(2)
  const [mediumWeight, setMediumWeight] = useState(1)

  function handleSave() {
    toast.success("Settings saved successfully", {
      description: `AI: ${aiEnabled ? "ON" : "OFF"} | Sensitivity: ${sensitivity} | Weights: ${criticalWeight}/${highWeight}/${mediumWeight}`,
    })
  }

  return (
    <div className="p-4 lg:p-6">
      <div className="mb-6">
        <h1 className="text-xl font-bold text-foreground">System Settings</h1>
        <p className="text-sm text-muted-foreground">
          Configure AI risk calculation and severity parameters
        </p>
      </div>

      <div className="mx-auto max-w-2xl space-y-6">
        {/* AI Risk Calculation */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Brain className="h-5 w-5 text-primary" />
              AI Risk Zone Detection
            </CardTitle>
            <CardDescription>
              Enable or disable automatic risk zone calculation based on incident data
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-sm font-medium text-foreground">
                  AI Risk Calculation
                </Label>
                <p className="text-xs text-muted-foreground">
                  Automatically classify areas as Green, Yellow, or Red zones
                </p>
              </div>
              <button
                onClick={() => setAiEnabled(!aiEnabled)}
                className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors ${
                  aiEnabled ? "bg-primary" : "bg-muted"
                }`}
                role="switch"
                aria-checked={aiEnabled}
              >
                <span
                  className={`pointer-events-none inline-block h-5 w-5 rounded-full bg-white shadow transition-transform ${
                    aiEnabled ? "translate-x-5" : "translate-x-0"
                  }`}
                />
              </button>
            </div>
          </CardContent>
        </Card>

        {/* Risk Sensitivity */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Gauge className="h-5 w-5 text-primary" />
              Risk Sensitivity Level
            </CardTitle>
            <CardDescription>
              How aggressively the system classifies risk zones
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex gap-2">
              {(["low", "medium", "high"] as const).map((level) => (
                <button
                  key={level}
                  onClick={() => setSensitivity(level)}
                  className={`flex-1 rounded-lg border px-4 py-3 text-sm font-medium capitalize transition-colors ${
                    sensitivity === level
                      ? "border-primary bg-primary/10 text-primary"
                      : "border-border bg-card text-muted-foreground hover:bg-secondary"
                  }`}
                >
                  {level}
                </button>
              ))}
            </div>
            <p className="mt-2 text-xs text-muted-foreground">
              {sensitivity === "low"
                ? "Only areas with many severe incidents are flagged"
                : sensitivity === "medium"
                  ? "Balanced detection for most use cases"
                  : "Aggressive detection, more areas may be flagged"}
            </p>
          </CardContent>
        </Card>

        {/* Severity Weights */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Weight className="h-5 w-5 text-primary" />
              Severity Weights
            </CardTitle>
            <CardDescription>
              Weight multiplier for each severity level in risk calculations
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {[
              {
                label: "Critical",
                value: criticalWeight,
                set: setCriticalWeight,
                color: "text-red-500",
              },
              {
                label: "High",
                value: highWeight,
                set: setHighWeight,
                color: "text-orange-500",
              },
              {
                label: "Medium",
                value: mediumWeight,
                set: setMediumWeight,
                color: "text-blue-500",
              },
            ].map((item) => (
              <div
                key={item.label}
                className="flex items-center justify-between"
              >
                <div>
                  <Label className={`text-sm font-medium ${item.color}`}>
                    {item.label}
                  </Label>
                  <p className="text-xs text-muted-foreground">
                    Weight: {item.value}x
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => item.set(Math.max(1, item.value - 1))}
                    className="flex h-8 w-8 items-center justify-center rounded-lg border border-border text-foreground hover:bg-secondary"
                  >
                    -
                  </button>
                  <span className="w-8 text-center text-sm font-bold text-foreground tabular-nums">
                    {item.value}
                  </span>
                  <button
                    onClick={() => item.set(Math.min(10, item.value + 1))}
                    className="flex h-8 w-8 items-center justify-center rounded-lg border border-border text-foreground hover:bg-secondary"
                  >
                    +
                  </button>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Button className="w-full" onClick={handleSave}>
          <Settings className="mr-1.5 h-4 w-4" />
          Save Settings
        </Button>
      </div>
    </div>
  )
}
