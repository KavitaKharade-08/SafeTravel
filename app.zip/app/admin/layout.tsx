"use client"

import { AdminSidebar } from "@/components/admin/admin-sidebar"

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="dark min-h-screen bg-background text-foreground">
      <AdminSidebar />
      <div className="lg:pl-64">{children}</div>
    </div>
  )
}
