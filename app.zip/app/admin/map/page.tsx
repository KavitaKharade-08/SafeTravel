"use client"

import { useEffect, useState } from "react"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { subscribeToIncidents, resolveIncident } from "@/lib/firestore"
import { formatTimeAgo } from "@/lib/helpers"
import { SeverityBadge, StatusBadge } from "@/components/severity-badge"
import { Map, MapPin, CheckCircle2, Loader2 } from "lucide-react"
import { toast } from "sonner"
import type { Incident } from "@/lib/types"

export default function AdminMapPage() {
  const [incidents, setIncidents] = useState<Incident[]>([])
  const [selected, setSelected] = useState<Incident | null>(null)
  const [resolvingId, setResolvingId] = useState<string | null>(null)

  useEffect(() => {
    const unsub = subscribeToIncidents(setIncidents)
    return unsub
  }, [])

  async function handleResolve(id: string) {
    setResolvingId(id)
    try {
      await resolveIncident(id)
      toast.success("Incident resolved")
      setSelected(null)
    } catch {
      toast.error("Failed to resolve")
    } finally {
      setResolvingId(null)
    }
  }

  const activeIncidents = incidents.filter((i) => i.status === "Active")

  return (
    <div className="p-4 lg:p-6">
      <div className="mb-6">
        <h1 className="text-xl font-bold text-foreground">Incident Map</h1>
        <p className="text-sm text-muted-foreground">
          {activeIncidents.length} active incidents on map
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1fr_360px]">
        {/* Map */}
        <Card>
          <CardContent className="p-0">
            <div className="overflow-hidden rounded-xl">
              <iframe
                title="Incident map"
                width="100%"
                height="500"
                style={{ border: 0 }}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                src={`https://maps.google.com/maps?q=${
                  selected
                    ? `${selected.latitude},${selected.longitude}`
                    : "40.7128,-74.006"
                }&z=${selected ? 15 : 12}&output=embed`}
              />
            </div>
          </CardContent>
        </Card>

        {/* Incident markers list */}
        <div className="space-y-3">
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">
            Incident Markers
          </h2>
          <div className="max-h-[480px] space-y-2 overflow-y-auto pr-1">
            {incidents.map((inc) => (
              <button
                key={inc.id}
                onClick={() => setSelected(inc)}
                className={`w-full rounded-lg border p-3 text-left transition-colors ${
                  selected?.id === inc.id
                    ? "border-primary bg-primary/10"
                    : "border-border bg-card hover:bg-secondary/50"
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <MapPin
                      className={`h-4 w-4 ${
                        inc.severity === "Critical"
                          ? "text-red-500"
                          : inc.severity === "High"
                            ? "text-orange-500"
                            : "text-blue-500"
                      }`}
                    />
                    <span className="text-sm font-medium text-foreground">
                      {inc.type}
                    </span>
                  </div>
                  <SeverityBadge severity={inc.severity} />
                </div>
                <p className="mt-1 text-xs text-muted-foreground">
                  {inc.latitude.toFixed(4)}, {inc.longitude.toFixed(4)} |{" "}
                  {formatTimeAgo(inc.timestamp)}
                </p>
              </button>
            ))}
          </div>

          {/* Selected incident detail */}
          {selected && (
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-base">
                  <Map className="h-4 w-4 text-primary" />
                  Incident Details
                </CardTitle>
                <CardDescription>ID: {selected.id.slice(0, 12)}...</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <span className="text-xs text-muted-foreground">Type</span>
                    <p className="font-medium text-foreground">{selected.type}</p>
                  </div>
                  <div>
                    <span className="text-xs text-muted-foreground">Severity</span>
                    <div className="mt-0.5">
                      <SeverityBadge severity={selected.severity} />
                    </div>
                  </div>
                  <div>
                    <span className="text-xs text-muted-foreground">Status</span>
                    <div className="mt-0.5">
                      <StatusBadge status={selected.status} />
                    </div>
                  </div>
                  <div>
                    <span className="text-xs text-muted-foreground">Reporter</span>
                    <p className="font-medium text-foreground truncate">
                      {selected.email}
                    </p>
                  </div>
                </div>
                {selected.description && (
                  <div>
                    <span className="text-xs text-muted-foreground">Description</span>
                    <p className="text-foreground">{selected.description}</p>
                  </div>
                )}
                {selected.status === "Active" && (
                  <Button
                    size="sm"
                    className="w-full"
                    onClick={() => handleResolve(selected.id)}
                    disabled={resolvingId === selected.id}
                  >
                    {resolvingId === selected.id ? (
                      <Loader2 className="mr-1 h-3.5 w-3.5 animate-spin" />
                    ) : (
                      <CheckCircle2 className="mr-1 h-3.5 w-3.5" />
                    )}
                    Mark as Resolved
                  </Button>
                )}
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
