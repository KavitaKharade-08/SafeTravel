"use client"

import { useState, useEffect } from "react"
import { AdminHeader } from "@/components/admin/admin-header"
import { IncidentTable } from "@/components/admin/incident-table"
import { SeedDataButton } from "@/components/admin/seed-data-button"
import { subscribeToIncidents } from "@/lib/firestore"
import { Radio, AlertTriangle, CheckCircle2, Clock } from "lucide-react"
import { toast } from "sonner"
import type { Incident } from "@/lib/types"

export default function AdminLiveFeed() {
  const [searchQuery, setSearchQuery] = useState("")
  const [incidents, setIncidents] = useState<Incident[]>([])

  useEffect(() => {
    const unsub = subscribeToIncidents(setIncidents)
    return unsub
  }, [])

  const activeCount = incidents.filter((i) => i.status === "Active").length
  const criticalCount = incidents.filter(
    (i) => i.severity === "Critical" && i.status === "Active"
  ).length
  const resolvedCount = incidents.filter((i) => i.status === "Resolved").length
  const avgResponseMs =
    incidents.length > 0
      ? incidents.reduce((sum, i) => sum + (Date.now() - i.timestamp), 0) /
        incidents.length
      : 0
  const avgResponseMin = Math.round(avgResponseMs / 60000)

  function handleGenerateReport() {
    toast.success("Report generated (mock)", {
      description: `${incidents.length} incidents exported.`,
    })
  }

  return (
    <div className="min-h-screen">
      <AdminHeader
        onSearch={setSearchQuery}
        onGenerateReport={handleGenerateReport}
      />

      <div className="px-4 py-6 lg:px-6">
        {/* Stats */}
        <div className="mb-6 grid grid-cols-2 gap-4 lg:grid-cols-4">
          <div className="rounded-xl border border-border bg-card p-4 shadow-sm">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Radio className="h-4 w-4" />
              Active Incidents
            </div>
            <p className="mt-1 text-2xl font-bold text-foreground">
              {activeCount}
            </p>
          </div>
          <div className="rounded-xl border border-border bg-card p-4 shadow-sm">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <AlertTriangle className="h-4 w-4 text-red-500" />
              Critical
            </div>
            <p className="mt-1 text-2xl font-bold text-red-500">
              {criticalCount}
            </p>
          </div>
          <div className="rounded-xl border border-border bg-card p-4 shadow-sm">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <CheckCircle2 className="h-4 w-4 text-green-500" />
              Resolved
            </div>
            <p className="mt-1 text-2xl font-bold text-green-500">
              {resolvedCount}
            </p>
          </div>
          <div className="rounded-xl border border-border bg-card p-4 shadow-sm">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Clock className="h-4 w-4" />
              Avg Response
            </div>
            <p className="mt-1 text-2xl font-bold text-foreground">
              {avgResponseMin}m
            </p>
          </div>
        </div>

        {/* Actions */}
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">
            Incident Feed
          </h2>
          <SeedDataButton />
        </div>

        {/* Table */}
        <IncidentTable searchQuery={searchQuery} />
      </div>
    </div>
  )
}
