"use client"

import { useState, useEffect } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Search, Bell, FileDown } from "lucide-react"
import { subscribeToActiveIncidents } from "@/lib/firestore"
import type { Incident } from "@/lib/types"

export function AdminHeader({
  onSearch,
  onGenerateReport,
}: {
  onSearch?: (query: string) => void
  onGenerateReport?: () => void
}) {
  const [search, setSearch] = useState("")
  const [activeCount, setActiveCount] = useState(0)

  useEffect(() => {
    const unsub = subscribeToActiveIncidents((incidents: Incident[]) => {
      setActiveCount(incidents.length)
    })
    return unsub
  }, [])

  return (
    <header className="flex flex-col gap-4 border-b border-border bg-card/50 px-6 py-4 lg:flex-row lg:items-center lg:justify-between">
      <div>
        <h1 className="text-xl font-bold text-foreground">
          Active Command Dashboard
        </h1>
        <p className="text-sm text-muted-foreground">
          System Live: Tracking tourist safety incidents
        </p>
      </div>

      <div className="flex items-center gap-3">
        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search incidents..."
            value={search}
            onChange={(e) => {
              setSearch(e.target.value)
              onSearch?.(e.target.value)
            }}
            className="w-48 pl-9 lg:w-64"
          />
        </div>

        {/* Notifications */}
        <Button variant="outline" size="icon" className="relative">
          <Bell className="h-4 w-4" />
          {activeCount > 0 && (
            <span className="absolute -right-1 -top-1 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-[10px] font-bold text-white">
              {activeCount > 9 ? "9+" : activeCount}
            </span>
          )}
          <span className="sr-only">{activeCount} active alerts</span>
        </Button>

        {/* Generate Report */}
        <Button size="sm" onClick={onGenerateReport}>
          <FileDown className="mr-1.5 h-4 w-4" />
          Generate Report
        </Button>

        {/* Admin avatar */}
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">
            A
          </div>
          <div className="hidden lg:block">
            <p className="text-sm font-medium text-foreground">Admin</p>
            <p className="text-xs text-muted-foreground">Super Admin</p>
          </div>
        </div>
      </div>
    </header>
  )
}
