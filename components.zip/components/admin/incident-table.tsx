"use client"

import { useEffect, useState } from "react"
import { subscribeToIncidents, resolveIncident } from "@/lib/firestore"
import { formatTimeAgo } from "@/lib/helpers"
import { SeverityBadge, StatusBadge } from "@/components/severity-badge"
import { Button } from "@/components/ui/button"
import { MapPin, CheckCircle2, Loader2 } from "lucide-react"
import { toast } from "sonner"
import type { Incident } from "@/lib/types"

export function IncidentTable({ searchQuery }: { searchQuery: string }) {
  const [incidents, setIncidents] = useState<Incident[]>([])
  const [, setTick] = useState(0)
  const [resolvingId, setResolvingId] = useState<string | null>(null)

  useEffect(() => {
    const unsub = subscribeToIncidents(setIncidents)
    return unsub
  }, [])

  // Live timer tick every second
  useEffect(() => {
    const interval = setInterval(() => setTick((t) => t + 1), 1000)
    return () => clearInterval(interval)
  }, [])

  const filtered = incidents.filter((inc) => {
    if (!searchQuery) return true
    const q = searchQuery.toLowerCase()
    return (
      inc.id.toLowerCase().includes(q) ||
      inc.email.toLowerCase().includes(q) ||
      inc.type.toLowerCase().includes(q) ||
      `${inc.latitude},${inc.longitude}`.includes(q)
    )
  })

  async function handleResolve(id: string) {
    setResolvingId(id)
    try {
      await resolveIncident(id)
      toast.success("Incident resolved")
    } catch {
      toast.error("Failed to resolve incident")
    } finally {
      setResolvingId(null)
    }
  }

  const isOldUnresolved = (inc: Incident) =>
    inc.status === "Active" && Date.now() - inc.timestamp > 3600000

  return (
    <div>
      {/* Desktop table */}
      <div className="hidden overflow-x-auto rounded-xl border border-border lg:block">
        <table className="w-full">
          <thead>
            <tr className="border-b border-border bg-secondary/50">
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Incident
              </th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Location
              </th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Severity
              </th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Response Timer
              </th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Status
              </th>
              <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Protocol
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {filtered.map((inc) => (
              <tr
                key={inc.id}
                className={`transition-colors hover:bg-secondary/30 ${
                  isOldUnresolved(inc)
                    ? "bg-red-500/5"
                    : ""
                }`}
              >
                <td className="px-4 py-3">
                  <div className="flex items-center gap-3">
                    <div
                      className={`flex h-9 w-9 items-center justify-center rounded-lg text-xs font-bold ${
                        inc.type === "SOS"
                          ? "bg-red-500/15 text-red-500"
                          : "bg-muted text-muted-foreground"
                      }`}
                    >
                      {inc.type === "SOS" ? "SOS" : inc.type.charAt(0)}
                    </div>
                    <div>
                      <p className="text-sm font-medium text-foreground">
                        {inc.type}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {inc.id.slice(0, 8)}... | {inc.email}
                      </p>
                    </div>
                  </div>
                </td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-1.5 text-sm text-foreground">
                    <MapPin className="h-3.5 w-3.5 text-muted-foreground" />
                    {inc.latitude.toFixed(4)}, {inc.longitude.toFixed(4)}
                  </div>
                </td>
                <td className="px-4 py-3">
                  <SeverityBadge severity={inc.severity} />
                </td>
                <td className="px-4 py-3">
                  <span
                    className={`text-sm font-mono tabular-nums ${
                      isOldUnresolved(inc)
                        ? "font-bold text-red-500"
                        : "text-muted-foreground"
                    }`}
                  >
                    {formatTimeAgo(inc.timestamp)}
                  </span>
                </td>
                <td className="px-4 py-3">
                  <StatusBadge status={inc.status} />
                </td>
                <td className="px-4 py-3 text-right">
                  {inc.status === "Active" ? (
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleResolve(inc.id)}
                      disabled={resolvingId === inc.id}
                    >
                      {resolvingId === inc.id ? (
                        <Loader2 className="mr-1 h-3.5 w-3.5 animate-spin" />
                      ) : (
                        <CheckCircle2 className="mr-1 h-3.5 w-3.5" />
                      )}
                      Resolve
                    </Button>
                  ) : (
                    <span className="text-xs text-green-500 font-medium">
                      Resolved
                    </span>
                  )}
                </td>
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr>
                <td
                  colSpan={6}
                  className="px-4 py-12 text-center text-sm text-muted-foreground"
                >
                  No incidents found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Mobile stacked cards */}
      <div className="space-y-3 lg:hidden">
        {filtered.map((inc) => (
          <div
            key={inc.id}
            className={`rounded-xl border border-border bg-card p-4 shadow-sm ${
              isOldUnresolved(inc) ? "border-red-500/30" : ""
            }`}
          >
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2">
                <div
                  className={`flex h-8 w-8 items-center justify-center rounded-lg text-xs font-bold ${
                    inc.type === "SOS"
                      ? "bg-red-500/15 text-red-500"
                      : "bg-muted text-muted-foreground"
                  }`}
                >
                  {inc.type === "SOS" ? "SOS" : inc.type.charAt(0)}
                </div>
                <div>
                  <p className="text-sm font-medium text-foreground">
                    {inc.type}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {inc.id.slice(0, 8)}...
                  </p>
                </div>
              </div>
              <StatusBadge status={inc.status} />
            </div>

            <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
              <div>
                <span className="text-muted-foreground">Location:</span>
                <p className="font-medium text-foreground">
                  {inc.latitude.toFixed(4)}, {inc.longitude.toFixed(4)}
                </p>
              </div>
              <div>
                <span className="text-muted-foreground">Severity:</span>
                <div className="mt-0.5">
                  <SeverityBadge severity={inc.severity} />
                </div>
              </div>
              <div>
                <span className="text-muted-foreground">Timer:</span>
                <p className="font-mono font-medium text-foreground">
                  {formatTimeAgo(inc.timestamp)}
                </p>
              </div>
              <div>
                <span className="text-muted-foreground">Reporter:</span>
                <p className="font-medium text-foreground truncate">
                  {inc.email}
                </p>
              </div>
            </div>

            {inc.status === "Active" && (
              <Button
                size="sm"
                className="mt-3 w-full"
                variant="outline"
                onClick={() => handleResolve(inc.id)}
                disabled={resolvingId === inc.id}
              >
                {resolvingId === inc.id ? (
                  <Loader2 className="mr-1 h-3.5 w-3.5 animate-spin" />
                ) : (
                  <CheckCircle2 className="mr-1 h-3.5 w-3.5" />
                )}
                Resolve Incident
              </Button>
            )}
          </div>
        ))}
        {filtered.length === 0 && (
          <div className="py-12 text-center text-sm text-muted-foreground">
            No incidents found.
          </div>
        )}
      </div>
    </div>
  )
}
