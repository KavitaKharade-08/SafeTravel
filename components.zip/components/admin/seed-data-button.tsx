"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { createIncident } from "@/lib/firestore"
import { generateSampleIncidents } from "@/lib/helpers"
import { Database, Loader2 } from "lucide-react"
import { toast } from "sonner"

export function SeedDataButton() {
  const [seeding, setSeeding] = useState(false)

  async function handleSeed() {
    setSeeding(true)
    try {
      const samples = generateSampleIncidents()
      for (const sample of samples) {
        await createIncident(sample)
      }
      toast.success(`Seeded ${samples.length} sample incidents`)
    } catch {
      toast.error("Failed to seed data")
    } finally {
      setSeeding(false)
    }
  }

  return (
    <Button variant="outline" size="sm" onClick={handleSeed} disabled={seeding}>
      {seeding ? (
        <Loader2 className="mr-1.5 h-4 w-4 animate-spin" />
      ) : (
        <Database className="mr-1.5 h-4 w-4" />
      )}
      Seed Demo Data
    </Button>
  )
}
