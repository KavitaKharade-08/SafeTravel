"use client"

import { useEffect, useState } from "react"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { subscribeToIncidents } from "@/lib/firestore"
import { calculateRiskZones, isInRiskZone } from "@/lib/helpers"
import { Map, Eye, EyeOff, AlertTriangle } from "lucide-react"
import type { Incident, RiskZone } from "@/lib/types"

export function SafetyMap() {
  const [incidents, setIncidents] = useState<Incident[]>([])
  const [zones, setZones] = useState<RiskZone[]>([])
  const [showHeatmap, setShowHeatmap] = useState(true)
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null)
  const [riskWarning, setRiskWarning] = useState<RiskZone | null>(null)

  useEffect(() => {
    const unsub = subscribeToIncidents((data) => {
      setIncidents(data)
      setZones(calculateRiskZones(data))
    })
    return unsub
  }, [])

  useEffect(() => {
    if (!navigator.geolocation) return
    const watchId = navigator.geolocation.watchPosition(
      (pos) => {
        const loc = { lat: pos.coords.latitude, lng: pos.coords.longitude }
        setUserLocation(loc)
      },
      () => {},
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 5000 }
    )
    return () => navigator.geolocation.clearWatch(watchId)
  }, [])

  useEffect(() => {
    if (userLocation && zones.length > 0) {
      const warning = isInRiskZone(userLocation.lat, userLocation.lng, zones)
      setRiskWarning(warning)
    }
  }, [userLocation, zones])

  const activeCount = incidents.filter((i) => i.status === "Active").length
  const mapCenter = userLocation
    ? `${userLocation.lat},${userLocation.lng}`
    : "40.7128,-74.006"

  return (
    <div className="space-y-4">
      {riskWarning && (
        <div className="flex items-center gap-3 rounded-xl border border-red-500/30 bg-red-500/10 p-4">
          <AlertTriangle className="h-6 w-6 shrink-0 text-red-500" />
          <div>
            <p className="font-semibold text-red-600 dark:text-red-400">
              You are entering a High Risk Area
            </p>
            <p className="text-sm text-red-600/80 dark:text-red-400/80">
              {riskWarning.incidentCount} incidents reported in this zone. Stay
              alert and avoid this area if possible.
            </p>
          </div>
        </div>
      )}

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Map className="h-5 w-5 text-primary" />
                Safety Heatmap
              </CardTitle>
              <CardDescription>
                {activeCount} active incident{activeCount !== 1 ? "s" : ""} tracked
              </CardDescription>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowHeatmap(!showHeatmap)}
            >
              {showHeatmap ? (
                <EyeOff className="mr-1.5 h-4 w-4" />
              ) : (
                <Eye className="mr-1.5 h-4 w-4" />
              )}
              {showHeatmap ? "Hide" : "Show"}
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="overflow-hidden rounded-lg border border-border">
            <iframe
              title="Safety heatmap"
              width="100%"
              height="350"
              style={{ border: 0 }}
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              src={`https://maps.google.com/maps?q=${mapCenter}&z=13&output=embed`}
            />
          </div>

          {showHeatmap && (
            <div className="space-y-3">
              {/* Legend */}
              <div className="flex items-center gap-4 text-xs">
                <span className="font-medium text-muted-foreground">Legend:</span>
                <span className="flex items-center gap-1.5">
                  <span className="h-3 w-3 rounded-full bg-green-500" />
                  Safe
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="h-3 w-3 rounded-full bg-yellow-500" />
                  Moderate
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="h-3 w-3 rounded-full bg-red-500" />
                  High Risk
                </span>
              </div>

              {/* Risk zones list */}
              {zones.length > 0 && (
                <div className="space-y-2">
                  {zones.map((zone) => (
                    <div
                      key={zone.id}
                      className="flex items-center justify-between rounded-lg border border-border bg-secondary/50 px-3 py-2"
                    >
                      <div className="flex items-center gap-2">
                        <span
                          className={`h-3 w-3 rounded-full ${
                            zone.level === "red"
                              ? "bg-red-500"
                              : zone.level === "yellow"
                                ? "bg-yellow-500"
                                : "bg-green-500"
                          }`}
                        />
                        <span className="text-sm font-medium text-foreground">
                          {zone.label}
                        </span>
                      </div>
                      <span className="text-xs text-muted-foreground">
                        {zone.incidentCount} incident{zone.incidentCount !== 1 ? "s" : ""} |{" "}
                        {zone.latitude.toFixed(3)}, {zone.longitude.toFixed(3)}
                      </span>
                    </div>
                  ))}
                </div>
              )}

              {zones.length === 0 && (
                <p className="text-center text-sm text-muted-foreground py-4">
                  No risk zones detected. Area appears safe.
                </p>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
