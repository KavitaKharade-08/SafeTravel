"use client"

import { useState } from "react"
import { useAuth } from "@/lib/auth-context"
import { createIncident } from "@/lib/firestore"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { FileWarning, Loader2, CheckCircle2 } from "lucide-react"
import { toast } from "sonner"
import type { IncidentType, SeverityLevel } from "@/lib/types"

const INCIDENT_TYPES: { value: IncidentType; label: string }[] = [
  { value: "Harassment", label: "Harassment" },
  { value: "Theft", label: "Theft" },
  { value: "Unsafe Area", label: "Unsafe Area" },
  { value: "Other", label: "Other" },
]

const SEVERITY_LEVELS: { value: SeverityLevel; label: string; color: string }[] = [
  { value: "Critical", label: "Critical", color: "bg-red-500" },
  { value: "High", label: "High", color: "bg-orange-500" },
  { value: "Medium", label: "Medium", color: "bg-blue-500" },
]

export function IncidentReportForm({ onClose }: { onClose?: () => void }) {
  const { user, profile } = useAuth()
  const [type, setType] = useState<IncidentType>("Theft")
  const [severity, setSeverity] = useState<SeverityLevel>("Medium")
  const [description, setDescription] = useState("")
  const [submitting, setSubmitting] = useState(false)
  const [submitted, setSubmitted] = useState(false)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!user) return

    setSubmitting(true)

    try {
      const position = await new Promise<GeolocationPosition>(
        (resolve, reject) => {
          navigator.geolocation.getCurrentPosition(resolve, reject, {
            enableHighAccuracy: true,
            timeout: 10000,
            maximumAge: 0,
          })
        }
      )

      const { latitude, longitude } = position.coords

      await createIncident({
        userId: user.uid,
        email: user.email || "",
        latitude,
        longitude,
        timestamp: Date.now(),
        severity,
        status: "Active",
        type,
        description: description || `${type} incident reported`,
        emergencyNumber: profile?.emergencyNumber || "",
      })

      setSubmitted(true)
      toast.success("Incident reported successfully!")
      setTimeout(() => {
        setSubmitted(false)
        setDescription("")
        setType("Theft")
        setSeverity("Medium")
        onClose?.()
      }, 2000)
    } catch {
      toast.error("Failed to report incident. Please try again.")
    } finally {
      setSubmitting(false)
    }
  }

  if (submitted) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center gap-3 py-12">
          <CheckCircle2 className="h-12 w-12 text-green-500" />
          <p className="text-lg font-semibold text-foreground">Report Submitted</p>
          <p className="text-sm text-muted-foreground">
            Your incident has been reported to authorities.
          </p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg">
          <FileWarning className="h-5 w-5 text-primary" />
          Report Incident
        </CardTitle>
        <CardDescription>
          Report a non-critical safety incident in your area
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="space-y-2">
            <Label>Incident Type</Label>
            <div className="grid grid-cols-2 gap-2">
              {INCIDENT_TYPES.map((t) => (
                <button
                  key={t.value}
                  type="button"
                  onClick={() => setType(t.value)}
                  className={`rounded-lg border px-3 py-2.5 text-sm font-medium transition-colors ${
                    type === t.value
                      ? "border-primary bg-primary/10 text-primary"
                      : "border-border bg-card text-muted-foreground hover:bg-secondary"
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Label>Severity Level</Label>
            <div className="flex gap-2">
              {SEVERITY_LEVELS.map((s) => (
                <button
                  key={s.value}
                  type="button"
                  onClick={() => setSeverity(s.value)}
                  className={`flex items-center gap-2 rounded-lg border px-3 py-2 text-sm font-medium transition-colors ${
                    severity === s.value
                      ? "border-primary bg-primary/10 text-primary"
                      : "border-border bg-card text-muted-foreground hover:bg-secondary"
                  }`}
                >
                  <span className={`h-2.5 w-2.5 rounded-full ${s.color}`} />
                  {s.label}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Input
              id="description"
              placeholder="Describe what happened..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </div>

          <div className="flex gap-2">
            <Button type="submit" disabled={submitting} className="flex-1">
              {submitting && <Loader2 className="h-4 w-4 animate-spin" />}
              Submit Report
            </Button>
            {onClose && (
              <Button type="button" variant="outline" onClick={onClose}>
                Cancel
              </Button>
            )}
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
