"use client"

import { useEffect, useState } from "react"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { MapPin, Loader2, MapPinOff } from "lucide-react"
import { Button } from "@/components/ui/button"

interface LocationData {
  latitude: number
  longitude: number
  accuracy: number
}

export function LocationDisplay() {
  const [location, setLocation] = useState<LocationData | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!navigator.geolocation) {
      setError("Geolocation is not supported by your browser")
      setLoading(false)
      return
    }

    const watchId = navigator.geolocation.watchPosition(
      (position) => {
        setLocation({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          accuracy: position.coords.accuracy,
        })
        setError(null)
        setLoading(false)
      },
      (err) => {
        setError(err.message)
        setLoading(false)
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 5000,
      }
    )

    return () => navigator.geolocation.clearWatch(watchId)
  }, [])

  function openInMaps() {
    if (location) {
      window.open(
        `https://www.google.com/maps?q=${location.latitude},${location.longitude}`,
        "_blank",
        "noopener,noreferrer"
      )
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg">
          <MapPin className="h-5 w-5 text-primary" />
          Live Location
        </CardTitle>
        <CardDescription>
          Your current GPS coordinates
        </CardDescription>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="flex items-center gap-3 text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" />
            <span className="text-sm">Acquiring location...</span>
          </div>
        ) : error ? (
          <div className="flex items-center gap-3 text-destructive">
            <MapPinOff className="h-4 w-4" />
            <span className="text-sm">{error}</span>
          </div>
        ) : location ? (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="rounded-lg bg-secondary p-3">
                <p className="text-xs font-medium text-muted-foreground">
                  Latitude
                </p>
                <p className="text-lg font-semibold tabular-nums text-foreground">
                  {location.latitude.toFixed(6)}
                </p>
              </div>
              <div className="rounded-lg bg-secondary p-3">
                <p className="text-xs font-medium text-muted-foreground">
                  Longitude
                </p>
                <p className="text-lg font-semibold tabular-nums text-foreground">
                  {location.longitude.toFixed(6)}
                </p>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <p className="text-xs text-muted-foreground">
                Accuracy: ~{Math.round(location.accuracy)}m
              </p>
              <Button variant="outline" size="sm" onClick={openInMaps}>
                <MapPin className="h-3 w-3" />
                Open in Maps
              </Button>
            </div>
            <div className="overflow-hidden rounded-lg border border-border">
              <iframe
                title="Current location map"
                width="100%"
                height="200"
                style={{ border: 0 }}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                src={`https://maps.google.com/maps?q=${location.latitude},${location.longitude}&z=15&output=embed`}
              />
            </div>
          </div>
        ) : null}
      </CardContent>
    </Card>
  )
}
