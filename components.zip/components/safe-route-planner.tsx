"use client"

import { useState, useEffect } from "react"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { subscribeToIncidents } from "@/lib/firestore"
import { calculateRiskZones } from "@/lib/helpers"
import { Navigation, Route, ShieldCheck, AlertTriangle } from "lucide-react"
import type { Incident, RiskZone } from "@/lib/types"

export function SafeRoutePlanner() {
  const [destination, setDestination] = useState("")
  const [planned, setPlanned] = useState(false)
  const [zones, setZones] = useState<RiskZone[]>([])
  const [incidents, setIncidents] = useState<Incident[]>([])

  useEffect(() => {
    const unsub = subscribeToIncidents((data) => {
      setIncidents(data)
      setZones(calculateRiskZones(data))
    })
    return unsub
  }, [])

  const redZones = zones.filter((z) => z.level === "red")
  const yellowZones = zones.filter((z) => z.level === "yellow")

  function handlePlanRoute(e: React.FormEvent) {
    e.preventDefault()
    if (destination.trim()) {
      setPlanned(true)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg">
          <Navigation className="h-5 w-5 text-primary" />
          Safe Route Planner
        </CardTitle>
        <CardDescription>
          Get the safest route to your destination, avoiding high-risk areas
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-5">
        <form onSubmit={handlePlanRoute} className="flex gap-2">
          <div className="flex-1 space-y-1.5">
            <Label htmlFor="destination" className="sr-only">
              Destination
            </Label>
            <Input
              id="destination"
              placeholder="Enter your destination..."
              value={destination}
              onChange={(e) => {
                setDestination(e.target.value)
                setPlanned(false)
              }}
            />
          </div>
          <Button type="submit" disabled={!destination.trim()}>
            <Route className="mr-1.5 h-4 w-4" />
            Plan
          </Button>
        </form>

        {planned && (
          <div className="space-y-3">
            {/* Safe route */}
            <div className="flex items-start gap-3 rounded-lg border border-green-500/30 bg-green-500/10 p-4">
              <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-green-600 dark:text-green-400" />
              <div>
                <p className="font-semibold text-green-700 dark:text-green-400">
                  Safest Route Recommended
                </p>
                <p className="text-sm text-green-600/80 dark:text-green-400/80">
                  Route to "{destination}" avoids {redZones.length} high-risk
                  {redZones.length !== 1 ? " zones" : " zone"} and {yellowZones.length}{" "}
                  moderate-risk {yellowZones.length !== 1 ? "zones" : "zone"}.
                </p>
              </div>
            </div>

            {/* Alternative risky route */}
            {redZones.length > 0 && (
              <div className="flex items-start gap-3 rounded-lg border border-red-500/30 bg-red-500/5 p-4">
                <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-red-500" />
                <div>
                  <p className="font-semibold text-red-600 dark:text-red-400">
                    Shortest Route (Not Recommended)
                  </p>
                  <p className="text-sm text-red-500/80 dark:text-red-400/80">
                    Passes through {redZones.length} high-risk area{redZones.length !== 1 ? "s" : ""} with{" "}
                    {incidents.filter((i) => i.status === "Active").length} active incidents.
                  </p>
                </div>
              </div>
            )}

            {/* Map embed */}
            <div className="overflow-hidden rounded-lg border border-border">
              <iframe
                title={`Route to ${destination}`}
                width="100%"
                height="250"
                style={{ border: 0 }}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                src={`https://maps.google.com/maps?q=${encodeURIComponent(destination)}&z=14&output=embed`}
              />
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
