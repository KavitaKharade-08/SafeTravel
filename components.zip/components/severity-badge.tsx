import type { SeverityLevel, IncidentStatus } from "@/lib/types"

export function SeverityBadge({ severity }: { severity: SeverityLevel }) {
  const config = {
    Critical: "bg-red-500/15 text-red-600 dark:text-red-400 animate-pulse",
    High: "bg-orange-500/15 text-orange-600 dark:text-orange-400",
    Medium: "bg-blue-500/15 text-blue-600 dark:text-blue-400",
  }

  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-semibold ${config[severity]}`}
    >
      <span
        className={`h-1.5 w-1.5 rounded-full ${
          severity === "Critical"
            ? "bg-red-500"
            : severity === "High"
              ? "bg-orange-500"
              : "bg-blue-500"
        }`}
      />
      {severity}
    </span>
  )
}

export function StatusBadge({ status }: { status: IncidentStatus }) {
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-semibold ${
        status === "Active"
          ? "bg-red-500/15 text-red-600 dark:text-red-400"
          : "bg-green-500/15 text-green-600 dark:text-green-400"
      }`}
    >
      <span
        className={`h-1.5 w-1.5 rounded-full ${
          status === "Active" ? "bg-red-500" : "bg-green-500"
        }`}
      />
      {status}
    </span>
  )
}
