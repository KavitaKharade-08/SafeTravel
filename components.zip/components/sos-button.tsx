"use client"

import { useState } from "react"
import { useAuth } from "@/lib/auth-context"
import { createIncident } from "@/lib/firestore"
import { simulateSMSAlert } from "@/lib/helpers"
import { Loader2, AlertTriangle } from "lucide-react"
import { toast } from "sonner"

export function SOSButton() {
  const { user, profile } = useAuth()
  const [sending, setSending] = useState(false)

  async function handleSOS() {
    if (!user) {
      toast.error("You must be logged in to send an SOS")
      return
    }

    setSending(true)

    try {
      const position = await new Promise<GeolocationPosition>(
        (resolve, reject) => {
          navigator.geolocation.getCurrentPosition(resolve, reject, {
            enableHighAccuracy: true,
            timeout: 20000,
            maximumAge: 0,
          })
        }
      )

      const { latitude, longitude } = position.coords

      await createIncident({
        userId: user.uid,
        email: user.email || "",
        latitude,
        longitude,
        timestamp: Date.now(),
        severity: "Critical",
        status: "Active",
        type: "SOS",
        description: "Emergency SOS triggered",
        emergencyNumber: profile?.emergencyNumber || "",
      })

      // Simulate SMS alert
      if (profile?.emergencyNumber) {
        simulateSMSAlert(
          profile.emergencyNumber,
          `EMERGENCY: ${user.email} triggered SOS at ${latitude.toFixed(4)}, ${longitude.toFixed(4)}`
        )
      }

      toast.success("SOS alert sent successfully!", {
        description: `Location: ${latitude.toFixed(4)}, ${longitude.toFixed(4)}. Emergency contact notified.`,
      })
    } catch (error) {
      if (error instanceof GeolocationPositionError) {
        switch (error.code) {
          case error.PERMISSION_DENIED:
            toast.error("Location permission denied", {
              description: "Please enable location access in your browser settings.",
            })
            break
          case error.POSITION_UNAVAILABLE:
            toast.error("Location unavailable", {
              description: "Unable to determine your position.",
            })
            break
          case error.TIMEOUT:
            toast.error("Location request timed out", {
              description: "Please try again.",
            })
            break
        }
      } else {
        toast.error("Failed to send SOS alert", {
          description: "Please try again.",
        })
      }
    } finally {
      setSending(false)
    }
  }

  return (
    <button
      onClick={handleSOS}
      disabled={sending}
      className="group relative flex h-44 w-44 items-center justify-center rounded-full bg-emergency text-emergency-foreground shadow-lg transition-all hover:scale-105 hover:shadow-xl focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-70 animate-pulse-emergency"
      aria-label="Send SOS emergency alert"
    >
      {sending ? (
        <div className="flex flex-col items-center gap-2">
          <Loader2 className="h-10 w-10 animate-spin" />
          <span className="text-sm font-medium">Sending...</span>
        </div>
      ) : (
        <div className="flex flex-col items-center gap-2">
          <AlertTriangle className="h-10 w-10" />
          <span className="text-2xl font-extrabold tracking-wider">SOS</span>
          <span className="text-xs font-medium opacity-80">
            Tap for Emergency
          </span>
        </div>
      )}
    </button>
  )
}
